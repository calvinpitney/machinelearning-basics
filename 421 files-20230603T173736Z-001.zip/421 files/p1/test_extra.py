#!/usr/bin/env python3

"""
Project 1 extra public tests 

You can (and should) write additional tests!
"""

import unittest
import p1

class BasicTests(unittest.TestCase):

    # Easy
    def test_valley(self):
        # This map has two solutions, and AT LEAST ONE should be correct
        candidate_sol = p1.find_path(p1.parse_map("valley.txt"), 2, 0, 2, 6)
        # Cost: 18
        true_sol = ['d', 'r', 'r', 'r', 'r', 'r', 'r', 'u']
        # true_sol = ['u', 'r', 'r', 'r', 'r', 'r', 'r', 'd']
        self.assertEqual(candidate_sol, true_sol)

    # Medium
    def test_maze(self):
        candidate_sol = p1.find_path(p1.parse_map("maze.txt"), 0, 1, 8, 9)
        # Cost: 20
        true_sol=['d','d','d','d','r','r','d','d','d','d','r','r','u','u','r','r','r','d','d','r']
        self.assertEqual(candidate_sol, true_sol)

    # Hard
    def test_horseshoe(self):
        # This map has two solutions, and AT LEAST ONE should be correct
        candidate_sol = p1.find_path(p1.parse_map("horseshoe.txt"), 0, 0, 3, 8)
        # Cost: 23
        true_sol=['d','d','d','d','d','d','d','r','r','r','r','r','r','r','r','r','r','u','u','l','u','l','u']
        #true_sol=['r','d','d','d','d','d','d','d','r','r','r','r','r','r','r','r','r','u','u','l','u','l','u']
        self.assertEqual(candidate_sol, true_sol)

if __name__ == "__main__":
    unittest.main()


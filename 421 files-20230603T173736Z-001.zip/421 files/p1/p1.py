#!/usr/bin/env python3

"""
CMSC 421
Project 1- A* search over simple map

Calvin Pitney: 114198709
"""

import sys
import Queue as queue

def parse_map(mapfile):
    """
    Parse the mapfile

    Returns the map as an appropriate data structure
    """
    maptext = open(mapfile, "r")
    matrix = []

    matrix.append([''])

    x = 0
    y = 0

    ch = maptext.read(1)
    while ch != '':
        while ch != '\n' and ch != '':

            while 1:
                if(ch == 'r' or ch == 'f' or ch == 'w' or ch == 'm' or ch == 'h'):
                    try:
                        matrix[x][y] = ch
                        break
                    except IndexError:
                        matrix[x].append(ch)




                
                
                # for x1 in range(0, len(matrix)):
                #     for y1 in range(0, len(matrix[0])):
                #         temp[x1][y1] = matrix[x1][y1]
                # matrix = temp
                # matrix[x][y] = ch
            ch = maptext.read(1)
            y+=1
        y=0
        sys.stdout.write("\n")
        ch = maptext.read(1)
        x+=1
        matrix.append([''])

    return matrix


def find_path(map_data, init_r, init_c, goal_r, goal_c):
    """
    Find the lowest cost find_path
    
    Returns the path as a list
    """
    def calcHeuristic(x, y, c):
        return ( ((x-goal_c)**2 + (y-goal_r))**2)**0.5 + costAt(x,y,c)

    def costAt(x, y, c) :
        l = map_data[x][y]
        if l == 'r':
            cx = 1
        elif l == 'f':
            cx = 2
        elif l == 'h':
            cx = 5
        elif l == 'm':
            cx = 10
        else:
            cx = 10000
        return cx + c

    # for z1 in range(0, len(map_data)-1):
    #     sys.stdout.write("  ::  ")
    #     for z2 in range(0, len(map_data[0])):
    #         sys.stdout.write(map_data[z1][z2])
    #         sys.stdout.write("  ::  ")
    #     sys.stdout.write("\n")  

    solution = []
    visited = []
    
    pq = queue.PriorityQueue()
    pq.put((0, 0, [], init_r, init_c))

    while (not pq.empty()):
        temp = pq.get()

        # print("DEQUEUED")
        # print(temp)
        x = temp[3]
        y = temp[4]
        g = temp[1]
        lastChar = 'x'

        solution = temp[2]
        visited.append((x,y))
        # print(solution)
        if(len(solution)>0):
            lastChar = (solution[len(solution)-1])

        if ( x == goal_r and y == goal_c):
            return solution

        solution1 = list(temp[2])
        solution2 = list(temp[2])
        solution3 = list(temp[2])
        solution4 = list(temp[2])

        solution1.append('l')
        solution2.append('r')
        solution3.append('u')
        solution4.append('d')
        
        #Q 4
        # print("x")
        # print(x)
        # print("y")
        # print(y)
        if(x>=0 and x < len(map_data) and y > 0 and y < len(map_data[0]) and visited.count((x,y-1)) == 0):
            # print("Left")
            # print(map_data[x][y-1])
            # print(x,y-1)
            # print(calcHeuristic(x,y-1,g))
            # print(costAt(x,y-1,g))
            pq.put((calcHeuristic(x,y-1,g), costAt(x,y-1,g), solution1, x, y-1))
        if(x>=0 and x < len(map_data) and y >= 0 and y < len(map_data[0])-1 and visited.count((x,y+1)) == 0):
            # print("Right")
            # print(map_data[x][y+1])
            # print(x,y+1)
            # print(calcHeuristic(x,y+1,g))
            # print(costAt(x,y+1,g))
            # print((calcHeuristic(x,y+1,g), costAt(x,y+1,g), solution2, x, y+1 ))
            pq.put((calcHeuristic(x,y+1,g), costAt(x,y+1,g), solution2, x, y+1 ))
        if(x>0 and x < len(map_data) and y >= 0 and y < len(map_data[0]) and visited.count((x-1,y)) == 0):
            # print("Up")
            # print(map_data[x-1][y])
            # print(x-1,y)
            # print(calcHeuristic(x-1,y,g))
            # print(costAt(x-1,y,g))
            pq.put((calcHeuristic(x-1,y,g),  costAt(x-1,y,g), solution3, x-1, y))
        if(x>=0 and x < len(map_data)-2 and y >= 0 and y <= len(map_data) and visited.count((x+1,y)) == 0):
            # print("Down")
            # print(x)
            # print(len(map_data))
            # print(len(map_data[0]))
            # print(y)
            # print(map_data[x+1][y])
            # print(x+1,y)
            # print(calcHeuristic(x+1,y,g))
            # print(costAt(x+1,y,g))
            pq.put((calcHeuristic(x+1,y,g), costAt(x+1,y,g), solution4, x+1, y))


    return None


def main(argv=None):
    """Main function"""
   
    # Read command line arguments
    mapfile = sys.argv[1]
    initial_row = int(sys.argv[2])
    initial_col = int(sys.argv[3])
    goal_row = int(sys.argv[4])
    goal_col = int(sys.argv[5])

    # Convert the mapfile into an appropriate data structure
    m = parse_map(mapfile)

    # Find the lowest cost path
    solution = find_path(m, initial_row, initial_col, goal_row, goal_col)

    print(solution)


# Run as: $ ./p1.py mapfile.txt init_row init_col goal_row goal_col
if __name__ == "__main__":
    main(sys.argv)

